import requests
import time
import json
import random
import uuid
from datetime import datetime

BASE_URL = "http://localhost:8000"

# --- INSTRUCTIONS FOR REAL IMPLEMENTATION ---
# To send real data from n8n / custom agents:
# 1. In your n8n workflow, add an HTTP Request node at the end of critical steps.
# 2. Method: POST -> URL: http://your-server-ip:8000/ingest
# 3. Body Parameters (JSON):
#    {
#      "execution_id": "{{ $execution.id }}",
#      "workflow_id": "{{ $workflow.id }}",
#      "step": "OpenAI: Generate Summary",
#      "status": "SUCCESS",
#      "duration": 2.45,
#      "tokens": 1050,
#      "cost": 0.0015,
#      "source": "n8n",
#      "tenant_id": "customer_1"
#    }
# ---------------------------------------------

def create_automation(name, desc, source):
    payload = {"name": name, "description": desc, "source": source}
    try:
        r = requests.post(f"{BASE_URL}/automation", json=payload)
        return r.json()['id']
    except Exception as e:
        print(f"Error creating automation: {e}")
        return None

def ingest_event(execution_id, workflow_id, step, status, duration, tokens, cost, source="langchain"):
    payload = {
        "execution_id": execution_id,
        "workflow_id": str(workflow_id),
        "step": step,
        "status": status,
        "duration": round(duration, 3),
        "tokens": int(tokens),
        "cost": round(cost, 6),
        "source": source,
        "tenant_id": f"tenant_{random.randint(1, 5)}"
    }
    try:
        requests.post(f"{BASE_URL}/ingest", json=payload)
    except Exception as e:
        print(f"Ingest failed: {e}")

# Realistic Workflow Templates
WORKFLOWS = [
    {
        "name": "Customer Support Triage",
        "description": "Reads incoming tickets, categorizes intent via LLM, and creates Zendesk issue.",
        "source": "n8n",
        "steps": [
            ("Webhook Trigger", 0.1, 0.5, 0),
            ("Extract Email Content", 0.2, 0.8, 0),
            ("LLM: Intent Classification", 1.5, 4.5, 300),
            ("Zendesk: Create Ticket", 0.5, 1.5, 0),
            ("Slack: Notify Team", 0.2, 0.6, 0)
        ]
    },
    {
        "name": "Financial Document OCR Pipeline",
        "description": "Extracts tables from PDFs and structures data into SQL.",
        "source": "langchain",
        "steps": [
            ("S3 File Upload", 0.5, 1.2, 0),
            ("Vision Model: OCR", 3.0, 8.0, 1500),
            ("LLM: Data Extraction", 2.0, 5.0, 800),
            ("PostgreSQL: Insert rows", 0.3, 1.0, 0)
        ]
    },
    {
        "name": "Social Media Auto-Responder",
        "description": "Monitors Twitter mentions and auto-replies to complaints.",
        "source": "custom_python",
        "steps": [
            ("Twitter API: Poll Mentions", 0.2, 0.8, 0),
            ("LLM: Sentiment Analysis", 0.8, 2.0, 150),
            ("Condition: Is Negative?", 0.1, 0.2, 0),
            ("LLM: Draft Apology", 1.5, 4.0, 250),
            ("Twitter API: Post Reply", 0.6, 2.0, 0)
        ]
    }
]

def simulate_workflow(workflow_id, workflow_template):
    exec_id = f"exec_{uuid.uuid4().hex[:10]}"
    print(f"\n[🚀 START] Flow: {workflow_template['name']} | ID: {exec_id}")
    
    total_duration = 0
    total_tokens = 0
    total_cost = 0

    for step_name, min_dur, max_dur, avg_tokens in workflow_template["steps"]:
        # Simulate dynamic processing time
        duration = random.uniform(min_dur, max_dur)
        
        # Simulate slight variability in tokens if applicable
        tokens = int(avg_tokens * random.uniform(0.8, 1.2)) if avg_tokens > 0 else 0
        
        # Simulate cost ($0.002 per 1k tokens - avg pricing model)
        cost = (tokens / 1000) * 0.002
        
        # Introduce random anomalies (15% chance of spike, 5% chance of failure)
        status = "SUCCESS"
        anomaly_roll = random.random()
        
        if anomaly_roll < 0.05:
            # Absolute failure
            status = "FAILED"
            duration = random.uniform(0.1, 1.0) # Fails quickly
            tokens = 0
            cost = 0
        elif anomaly_roll < 0.20:
            # Latency spike anomaly
            duration = duration * random.uniform(3.0, 6.0)

        # Send it
        ingest_event(exec_id, workflow_id, step_name, status, duration, tokens, cost, source=workflow_template["source"])
        print(f"  ➜ {step_name.ljust(30)} [{status}] {duration:.2f}s | {tokens} tkns | ${cost:.5f}")
        
        total_duration += duration
        total_tokens += tokens
        total_cost += cost

        # Add physical delay between HTTP requests to simulate real-time processing visually on the dashboard
        time.sleep(duration / 2) # Speed up simulation slightly

        if status == "FAILED":
            print(f"[❌ FAILED] Execution aborted at step: {step_name}")
            break

    print(f"[✅ END] {exec_id} | Total Time: {total_duration:.2f}s | Tokens: {total_tokens} | Cost: ${total_cost:.5f}")

if __name__ == "__main__":
    print("="*60)
    print("AI OBSERVABILITY: DYNAMIC REAL DATA GENERATOR")
    print("="*60)
    
    # Init workflow schemas in DB
    print("\nRegistering Workflows...")
    registered = []
    for wf in WORKFLOWS:
        w_id = create_automation(wf["name"], wf["description"], wf["source"])
        if w_id:
            registered.append((w_id, wf))
    
    if not registered:
        print("Failed to register workflows. Is the backend running?")
        exit(1)

    print("\nStarting continuous payload stream. Press Ctrl+C to stop.")
    try:
        while True:
            # Pick a random workflow to simulate
            wf_id, wf_template = random.choice(registered)
            simulate_workflow(wf_id, wf_template)
            
            # Wait a few seconds before the next organic run triggers
            sleep_time = random.uniform(2, 6)
            print(f"\nWaiting {sleep_time:.1f}s for next event trigger...\n")
            time.sleep(sleep_time)

    except KeyboardInterrupt:
        print("\nGenerator Stopped.")
