import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import ExecutionCard from "../components/ExecutionCard";
import { RxCountdownTimer, RxArrowLeft } from "react-icons/rx";
import { getAutomation, getAutomationExecutions } from "../services/api";
import LoadingSpinner from "../components/LoadingSpinner";

export default function AutomationDetail() {
    const { id } = useParams();
    const [automation, setAutomation] = useState(null);
    const [executions, setExecutions] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function loadData() {
            setLoading(true);
            try {
                const autoData = await getAutomation(id);
                setAutomation(autoData);

                const execs = await getAutomationExecutions(id);
                setExecutions(execs);
            } catch (e) {
                console.error(e);
            } finally {
                setLoading(false);
            }
        }
        loadData();
    }, [id]);

    if (loading) {
        return <LoadingSpinner />;
    }

    if (!automation) {
        return (
            <div className="p-10 text-center font-sf-medium">
                <Link to="/dashboard" className="text-blue-400 hover:text-blue-300 transition-colors mb-4 inline-block">&larr; Back home</Link>
                <div className="text-red-400 text-xl">Automation not found.</div>
            </div>
        );
    }

    return (
        <div className="p-4 md:p-10 max-w-6xl mx-auto font-sf-regular">
            <Link to="/dashboard" className="flex items-center gap-2 bg-white/5 p-2 rounded-full px-5 hover:bg-white/10 border border-white/5 text-neutral-400 hover:text-white mb-10 w-fit cursor-pointer transition-all duration-200 shadow-sm font-sf-medium text-sm">
                <RxArrowLeft /> Back to Dashboard
            </Link>

            <div className="bg-black/30 backdrop-blur-md border border-white/5 rounded-3xl p-8 mb-12 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 blur-[80px] pointer-events-none"></div>

                <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-4">
                    <div>
                        <h2 className="flex items-center gap-4 text-white text-3xl font-sf-bold mb-3 tracking-tight">
                            <RxCountdownTimer className="text-blue-400" />
                            {automation.name}
                        </h2>
                        
                        <p className="text-neutral-400 text-lg line-clamp-2 max-w-3xl">
                            {automation.description || "No description provided."}
                        </p>
                    </div>
                </div>

                <div className="flex gap-4 mt-8 pt-6 border-t border-white/10">
                    <span className="bg-white/5 px-4 py-1.5 rounded-lg border border-white/5 text-sm font-sf-medium text-neutral-300">
                        <span className="text-neutral-500 mr-2 uppercase tracking-wider text-xs font-sf-semibold">Source</span>
                        {automation.source}
                    </span>
                    <span className="bg-white/5 px-4 py-1.5 rounded-lg border border-white/5 text-sm font-sf-medium text-neutral-300">
                        <span className="text-neutral-500 mr-2 uppercase tracking-wider text-xs font-sf-semibold">Total Runs</span>
                        {executions.length}
                    </span>
                </div>
            </div>


            <h3 className="text-xl text-white font-sf-bold mb-6 tracking-tight border-b border-white/10 pb-4 flex items-center gap-3">
                Execution History
            </h3>

            {executions.length === 0 ? (
                <div className="text-center py-12 bg-black/20 rounded-2xl border border-white/5 text-neutral-500">
                    No executions found for this automation yet.
                </div>
            ) : (
                <div className="space-y-4">
                    {executions.map(e => (
                        <ExecutionCard key={e.execution_id} data={e} />
                    ))}
                </div>
            )}
        </div>
    );
}
