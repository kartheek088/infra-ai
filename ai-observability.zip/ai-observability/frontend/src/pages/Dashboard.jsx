import { useEffect, useState } from "react";
import { getAutomations, getRecentExecutions, getMetrics } from "../services/api";

import ExecutionDashboard from "../components/ExecutionDashboard";
import AutomationCard from "../components/AutomationCard";
import ExecutionCard from "../components/ExecutionCard";

import { RxCountdownTimer, RxLightningBolt } from "react-icons/rx";
import { FaBolt, FaBug, FaClock, FaServer } from "react-icons/fa";

export default function Dashboard() {

    const [automations, setAutomations] = useState([]);
    const [recentExecutions, setRecentExecutions] = useState([]);
    const [metrics, setMetrics] = useState({ executions: 0, failures: 0, avg_latency: 0, automations: 0 });
    const [loading, setLoading] = useState(true);
    const [execLoading, setExecLoading] = useState(true);

    useEffect(() => {
        async function loadData() {
            try {
                const [autoData, mData] = await Promise.all([
                    getAutomations(),
                    getMetrics()
                ]);
                setAutomations(autoData);
                setMetrics(mData);
            } catch (e) {
                console.error(e);
            } finally {
                setLoading(false);
            }
        }
        
        async function loadExecutions() {
            try {
                const data = await getRecentExecutions();
                setRecentExecutions(data);
            } catch (e) {
                console.error(e);
            } finally {
                setExecLoading(false);
            }
        }

        loadData();
        loadExecutions();
    }, []);

    return (
        <div className="space-y-16 max-w-7xl mx-auto font-sf-regular">

            {/* ================= METRICS ================= */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">

                <div className="bg-black/30 backdrop-blur-md border border-white/5 p-6 rounded-2xl shadow-xl hover:border-white/10 transition-colors">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 text-green-400 font-sf-semibold">
                            <FaBolt />
                            <p className="text-sm tracking-widest uppercase">Total Execs</p>
                        </div>
                    </div>
                    <h1 className="text-4xl mt-4 font-sf-bold tracking-tighter shadow-sm">{metrics.executions}</h1>
                </div>

                <div className="bg-black/30 backdrop-blur-md border border-white/5 p-6 rounded-2xl shadow-xl hover:border-white/10 transition-colors">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 text-red-500 font-sf-semibold">
                            <FaBug />
                            <p className="text-sm tracking-widest uppercase">Failures</p>
                        </div>
                    </div>
                    <h1 className="text-4xl mt-4 font-sf-bold tracking-tighter shadow-sm">{metrics.failures}</h1>
                </div>

                <div className="bg-black/30 backdrop-blur-md border border-white/5 p-6 rounded-2xl shadow-xl hover:border-white/10 transition-colors">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 text-yellow-400 font-sf-semibold">
                            <FaClock />
                            <p className="text-sm tracking-widest uppercase">Avg Latency</p>
                        </div>
                    </div>
                    <h1 className="text-4xl mt-4 font-sf-bold tracking-tighter shadow-sm">{metrics.avg_latency}s</h1>
                </div>
                
                <div className="bg-black/30 backdrop-blur-md border border-white/5 p-6 rounded-2xl shadow-xl hover:border-white/10 transition-colors">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 text-blue-400 font-sf-semibold">
                            <FaServer />
                            <p className="text-sm tracking-widest uppercase">Automations</p>
                        </div>
                    </div>
                    <h1 className="text-4xl mt-4 font-sf-bold tracking-tighter shadow-sm">{metrics.automations}</h1>
                </div>

            </div>

            {/* ================= EXECUTION ANALYZER ================= */}
            <section className="bg-black/20 border border-white/5 rounded-3xl p-6 md:p-10 shadow-2xl relative overflow-hidden backdrop-blur-sm">
                <div className="absolute top-0 right-0 w-64 h-64 bg-green-500/10 blur-[100px] pointer-events-none"></div>
                
                <h2 className="text-2xl text-green-400 mb-8 font-sf-bold tracking-tight">
                    <span className="bg-green-500/20 text-green-400 px-3 py-1 rounded-md text-sm mr-3 font-mono">POST /analyze</span>
                    Execution Analyzer
                </h2>
                
                <ExecutionDashboard />
            </section>

            {/* ================= RECENT EXECUTIONS ================= */}
            <section>
                <h2 className="flex items-center gap-3 text-xl text-white mb-8 font-sf-bold tracking-tight border-b border-white/10 pb-4">
                    <RxLightningBolt className="text-green-400"/>
                    Recent Executions Flow
                </h2>

                {execLoading ? (
                    <div className="animate-pulse flex flex-col gap-4">
                        {[1, 2, 3].map(i => <div key={i} className="h-32 bg-white/5 rounded-2xl border border-white/5"></div>)}
                    </div>
                ) : recentExecutions.length === 0 ? (
                    <div className="text-center py-10 bg-black/20 rounded-2xl border border-white/5 text-neutral-500">
                        No executions recorded yet. Fire a webhook to populate.
                    </div>
                ) : (
                    <div className="space-y-5">
                        {recentExecutions.map(e => (
                            <ExecutionCard key={e.execution_id} data={e} />
                        ))}
                    </div>
                )}
            </section>

            {/* ================= AUTOMATIONS ================= */}
            <section className="pb-20">
                <h2 className="flex items-center gap-3 text-xl text-white mb-8 font-sf-bold tracking-tight border-b border-white/10 pb-4">
                    <RxCountdownTimer className="text-blue-400" />
                    Registry / Saved Workflows
                </h2>

                {loading ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
                        {[1, 2, 3].map(i => <div key={i} className="h-48 bg-white/5 rounded-2xl border border-white/5"></div>)}
                    </div>
                ) : automations.length === 0 ? (
                    <div className="text-center py-10 border border-dashed border-white/20 rounded-2xl text-neutral-500 font-sf-medium">
                        No automations tracked. They'll pop up here seamlessly once ingested.
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {automations.map(a => (
                            <AutomationCard key={a.id} automation={a} />
                        ))}
                    </div>
                )}
            </section>

        </div>
    );
}
