import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { RxArrowLeft } from "react-icons/rx";
import { getExecutionSummary } from "../services/api";
import ExecutionTrace from "../components/ExecutionTrace";
import LoadingSpinner from "../components/LoadingSpinner";

export default function ExecutionDetail() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [execution, setExecution] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        async function loadExecution() {
            setLoading(true);
            try {
                const data = await getExecutionSummary(id);
                setExecution(data);
            } catch (err) {
                console.error("Failed to load execution", err);
                setError(err.message || "Failed to fetch details.");
            } finally {
                setLoading(false);
            }
        }
        if (id) {
            loadExecution();
        }
    }, [id]);

    if (loading) {
        return <LoadingSpinner />;
    }

    if (error || !execution) {
        return (
            <div className="p-10 font-sf-medium text-center">
                <button onClick={() => navigate(-1)} className="text-blue-400 hover:text-blue-300 mb-4 inline-block">&larr; Back</button>
                <div className="text-red-500 text-xl">{error || "Execution detail could not be loaded."}</div>
            </div>
        );
    }

    // Parse JSON if needed
    const timeline = typeof execution.timeline === "string" ? JSON.parse(execution.timeline) : execution.timeline;
    const anomalies = typeof execution.anomalies === "string" ? JSON.parse(execution.anomalies) : execution.anomalies;
    
    const { explanation, health, total_tokens, total_cost, total_duration, automation_name } = execution;
    const steps = timeline?.steps || [];
    const durationFromTimeline = timeline?.total_duration || total_duration;

    return (
        <div className="p-4 md:p-10 max-w-6xl mx-auto font-sf-regular animate-in slide-in-from-bottom-4 duration-500">
            <button onClick={() => navigate(-1)} className="flex items-center gap-2 bg-white/5 px-5 py-2 rounded-full border border-white/5 text-neutral-400 hover:text-white mb-8 w-fit cursor-pointer shadow-sm transition-all duration-200 font-sf-medium text-sm">
                <RxArrowLeft /> Back
            </button>

            {/* HEADER LOG */}
            <div className="bg-black/40 border border-white/10 rounded-3xl p-8 mb-8 backdrop-blur-md shadow-2xl relative overflow-hidden">
                <div className={`absolute top-0 right-0 w-64 h-64 blur-[120px] pointer-events-none ${health === 'SUCCESS' ? 'bg-green-500/10' : health === 'FAILED' ? 'bg-red-500/10' : 'bg-yellow-500/10'}`}></div>

                <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                    <div>
                        <h2 className="text-white text-3xl font-sf-bold mb-3 tracking-tight flex items-center flex-wrap gap-4">
                            Execution Trace
                            <span className={`text-sm px-4 py-1.5 font-sf-semibold rounded-full border shadow-inner ${health === 'SUCCESS' ? 'bg-green-500/10 text-green-400 border-green-500/30' : health === 'FAILED' ? 'bg-red-500/10 text-red-400 border-red-500/30' : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30'}`}>
                                {health}
                            </span>
                        </h2>
                        <div className="flex gap-4 items-center">
                            <p className="text-neutral-500 font-mono text-sm tracking-tight">{id}</p>
                            {automation_name && (
                                <span className="bg-blue-500/10 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-md text-xs font-sf-medium">
                                    {automation_name}
                                </span>
                            )}
                        </div>
                    </div>
                    
                    <div className="flex gap-4">
                        <div className="bg-black/60 p-4 rounded-xl border border-white/5 shadow-inner min-w-28">
                            <p className="text-neutral-400 text-xs font-sf-semibold uppercase tracking-widest mb-1">Time</p>
                            <p className="text-white text-xl font-sf-bold">{durationFromTimeline?.toFixed(2)}s</p>
                        </div>
                        <div className="bg-black/60 p-4 rounded-xl border border-white/5 shadow-inner min-w-28">
                            <p className="text-neutral-400 text-xs font-sf-semibold uppercase tracking-widest mb-1">Cost</p>
                            <p className="text-white text-xl font-sf-bold">${Number(total_cost).toFixed(5)}</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* TRACE COMPONENT */}
            <div className="bg-black/20 border border-white/5 rounded-3xl p-8 mb-8 shadow-xl">
                <h2 className="text-lg text-green-400 mb-6 font-sf-semibold uppercase tracking-wider flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.8)]"></div>
                    Pipeline Sequence
                </h2>
                <ExecutionTrace steps={steps} />
            </div>

            {/* ANOMALIES & SUMMARY ROW */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* ANOMALIES */}
                <div className="bg-black/20 border border-white/5 rounded-3xl p-8 shadow-xl">
                    <h2 className="text-lg text-red-400 mb-6 font-sf-semibold uppercase tracking-wider flex items-center gap-3">
                         <div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]"></div>
                         Health Anomalies
                    </h2>

                    {anomalies && anomalies.length > 0 ? (
                        <div className="space-y-3">
                            {anomalies.map((a, i) => (
                                <div key={i} className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex gap-3 text-red-300 font-sf-medium">
                                    <span>⚠</span>
                                    <span>{a}</span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-5 text-green-400 font-sf-medium text-center">
                            No anomalies detected in this execution.
                        </div>
                    )}
                </div>

                {/* AI SUMMARY */}
                <div className="bg-black/20 border border-green-500/10 rounded-3xl p-8 shadow-xl relative overflow-hidden group hover:border-green-500/30 transition-colors">
                    <div className="absolute top-0 right-0 bg-green-500 text-black px-3 py-1 font-sf-bold text-xs rounded-bl-xl tracking-widest uppercase">Groq AI</div>
                    
                    <h2 className="text-lg text-white mb-6 font-sf-semibold uppercase tracking-wider flex items-center gap-3">
                        <span className="text-xl">✨</span> Post-Execution Intelligence
                    </h2>

                    <div className="text-neutral-300 font-sf-regular leading-loose whitespace-pre-wrap text-[15px]">
                        {explanation || "Analysis unavailable."}
                    </div>
                </div>
            </div>

        </div>
    );
}
