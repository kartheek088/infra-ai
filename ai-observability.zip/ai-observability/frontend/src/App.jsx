import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Dashboard from "./pages/Dashboard";
import AutomationDetail from "./pages/AutomationDetail";
import ExecutionDetail from "./pages/ExecutionDetail";

function App() {
  return (
    <BrowserRouter>
      {/* GLOBAL BACKGROUND MESH */}
      <div className="mesh-bg fixed inset-0 -z-10" />
      <div className="blob3"></div>

      <div className="flex min-h-screen text-neutral-200 font-sf-regular">
        {/* Main Area */}
        <div className="flex-1 flex flex-col">

          {/* HERO HEADER */}
          <section className="py-20 text-center">
            <h1 className="text-5xl tracking-tighter bg-clip-text text-transparent bg-[linear-gradient(to_right,#86efac,#fef08a,#38bdf8,#86efac)] bg-[length:200%_auto] animate-gradient-flow font-sf-semibold">
              Automation Reality Index
            </h1>
            <p className="mt-4 text-neutral-400 text-sm tracking-wide">
              Monitor LLM Executions • Token Usage • Cost • System Health
            </p>
          </section>

          {/* ROUTES CONTAINER */}
          <main className="flex-1 overflow-y-auto p-4 md:p-8">
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/automation/:id" element={<AutomationDetail />} />
              <Route path="/execution/:id" element={<ExecutionDetail />} />
            </Routes>
          </main>

        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
