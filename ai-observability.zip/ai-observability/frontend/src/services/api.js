const BASE_URL = "http://localhost:8000"

export const getExecutionSummary = async (executionId) => {
    if (!executionId?.trim()) {
        throw new Error('Execution ID is required')
    }

    const res = await fetch(`${BASE_URL}/execution/${executionId.trim()}`)

    if (!res.ok) {
        if (res.status === 404) throw new Error('Execution not found in database')
        throw new Error('Backend error')
    }
    return res.json()
}

export async function saveAutomation(data) {
    const res = await fetch(`${BASE_URL}/automation`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    return res.json()
}

export async function getAutomations() {
    const res = await fetch(`${BASE_URL}/automation`)
    return res.json()
}

export async function getAutomation(id) {
    const res = await fetch(`${BASE_URL}/automation`)
    const automations = await res.json()
    // Find the one matching id
    return automations.find(a => parseInt(a.id) === parseInt(id))
}

export async function getAutomationExecutions(id) {
    const res = await fetch(`${BASE_URL}/automation/${id}/executions`)
    return res.json()
}

export async function getRecentExecutions() {
    const res = await fetch(`${BASE_URL}/executions/recent`)
    return res.json()
}

export async function getMetrics() {
    const res = await fetch(`${BASE_URL}/metrics`)
    return res.json()
}
