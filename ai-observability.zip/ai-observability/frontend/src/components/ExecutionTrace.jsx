import React from "react";

export default function ExecutionTrace({ steps = [] }) {
    if (!steps.length) {
        return (
            <p className="text-gray-500 text-center py-10 font-sf-regular">
                No execution data available.
            </p>
        );
    }

    const getColor = (duration) => {
        if (duration > 2) return "border-red-500";
        if (duration > 1) return "border-yellow-400";
        return "border-green-400";
    };

    return (
        <div className="flex items-center overflow-x-auto gap-6 py-4 font-sf-regular">
            {steps.map((step, index) => {
                const isLast = index === steps.length - 1;
                const duration = step.duration || 0;

                return (
                    <div key={index} className="flex items-center gap-6">
                        {/* NODE */}
                        <div className={`min-w-[160px] bg-black/40 border ${getColor(duration)} rounded-xl p-4 shadow-lg backdrop-blur-sm`}>
                            <p className="text-sm text-gray-400">
                                {step.step}
                            </p>
                            <h3 className="text-lg font-semibold text-white mt-1">
                                {duration.toFixed(2)}s
                            </h3>
                            <p className={`text-xs mt-2 font-sf-semibold ${step.status === "SUCCESS"
                                    ? "text-green-400"
                                    : "text-red-400"
                                }`}>
                                {step.status}
                            </p>
                            
                            {/* PROGRESS BAR */}
                            <div className="w-full bg-white/10 h-1 mt-3 rounded overflow-hidden">
                                <div
                                    className="bg-blue-400 h-1 rounded transition-all duration-300"
                                    style={{ width: `${Math.min(duration * 50, 100)}%` }}
                                />
                            </div>
                        </div>

                        {/* ARROW */}
                        {!isLast && (
                            <div className="text-gray-500 text-xl font-sf-regular animate-pulse">
                                →
                            </div>
                        )}
                    </div>
                );
            })}
        </div>
    );
}
