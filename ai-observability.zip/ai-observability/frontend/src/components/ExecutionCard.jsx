import React from "react";
import { Link } from "react-router-dom";

export default function ExecutionCard({ data, execution }) {
    const d = data || execution;
    if (!d) return null;

    const {
        execution_id,
        health,
        anomalies = [],
        total_tokens = 0,
        total_cost = 0,
        explanation = "",
        timeline = {},
        created_at
    } = d;

    // Handle parsed or unparsed JSON
    const parsedTimeline = typeof timeline === "string" ? JSON.parse(timeline) : timeline;
    const parsedAnomalies = typeof anomalies === "string" ? JSON.parse(anomalies) : anomalies;
    
    const steps = parsedTimeline?.steps || [];

    const formatDate = (dateStr) => {
        if (!dateStr) return null;
        const dt = new Date(dateStr);
        return dt.toLocaleString('en-US', {
            month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    };

    const card = (
        <div className="bg-black/40 border border-white/10 rounded-xl overflow-hidden backdrop-blur-md shadow-xl font-sf-regular hover:border-white/30 transition-all duration-300">
            {/* TERMINAL HEADER */}
            <div className="flex items-center justify-between gap-4 px-6 py-4 bg-white/5 border-b border-white/10 shadow-sm">
                <div className="flex items-center gap-2">
                    <div className="flex gap-2">
                        <div className="w-3 h-3 rounded-full bg-red-500 shadow-sm"></div>
                        <div className="w-3 h-3 rounded-full bg-yellow-400 shadow-sm"></div>
                        <div className="w-3 h-3 rounded-full bg-green-500 shadow-sm"></div>
                    </div>
                    <span className="ml-4 text-sm text-neutral-300 tracking-tight font-sf-medium">
                        execution_id: <span className="text-green-300 font-sf-semibold ml-1">{execution_id}</span>
                    </span>
                </div>
                {created_at && (
                    <span className="text-xs text-neutral-500 hidden sm:block">
                        {formatDate(created_at)}
                    </span>
                )}
            </div>

            {/* CARD BODY */}
            <div className="p-6">
                {/* SUMMARY METRICS */}
                <div className="mb-6 grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-white/5 p-4 rounded-lg border border-white/5">
                        <p className="text-green-400 text-xs font-sf-semibold tracking-wider uppercase mb-1">Status</p>
                        <p className={`text-lg font-sf-bold ${health === 'SUCCESS' ? 'text-green-400' : health === 'FAILED' ? 'text-red-400' : 'text-yellow-400'}`}>
                            {health}
                        </p>
                    </div>
                    <div className="bg-white/5 p-4 rounded-lg border border-white/5">
                        <p className="text-green-400 text-xs font-sf-semibold tracking-wider uppercase mb-1">Duration</p>
                        <p className="text-white text-lg font-sf-semibold">{parsedTimeline?.total_duration?.toFixed(2) || "0.00"}s</p>
                    </div>
                    <div className="bg-white/5 p-4 rounded-lg border border-white/5">
                        <p className="text-green-400 text-xs font-sf-semibold tracking-wider uppercase mb-1">Tokens</p>
                        <p className="text-white text-lg font-sf-semibold">{total_tokens.toLocaleString()}</p>
                    </div>
                    <div className="bg-white/5 p-4 rounded-lg border border-white/5">
                        <p className="text-green-400 text-xs font-sf-semibold tracking-wider uppercase mb-1">Cost</p>
                        <p className="text-white text-lg font-sf-semibold">${Number(total_cost).toFixed(5)}</p>
                    </div>
                </div>

                {/* TIMELINE OVERVIEW */}
                {steps.length > 0 && (
                    <div className="mb-6">
                        <p className="text-green-400 text-xs font-sf-semibold tracking-wider uppercase mb-2 block border-y border-white/10 py-2">
                             Pipeline Sequence
                        </p>
                        <div className="flex flex-wrap items-center gap-2 mt-3 text-sm tracking-wide">
                            {steps.slice(-5).map((s, idx) => (
                                <React.Fragment key={idx}>
                                    <span className="px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-md text-neutral-300">
                                        {s.step || s}
                                    </span>
                                    {idx !== Math.min(steps.length, 5) - 1 && <span className="text-neutral-600 font-sf-bold text-lg leading-none">→</span>}
                                </React.Fragment>
                            ))}
                            {steps.length > 5 && <span className="text-neutral-500 text-xs ml-2">({steps.length - 5} more steps...)</span>}
                        </div>
                    </div>
                )}

                {/* ANOMALIES */}
                {parsedAnomalies && parsedAnomalies.length > 0 && (
                    <div className="mb-6">
                        <h4 className="text-red-400 text-xs font-sf-semibold tracking-wider uppercase mb-2 border-y border-white/10 py-2">
                             Anomalies Detected
                        </h4>
                        <ul className="space-y-1 mt-2">
                            {parsedAnomalies.map((a, i) => (
                                <li key={i} className="text-red-300 text-sm flex gap-2">
                                    <span className="text-red-500">⚠</span> {a}
                                </li>
                            ))}
                        </ul>
                    </div>
                )}

                {/* EXPLANATION */}
                {explanation && (
                    <div className="mt-4">
                        <h4 className="text-green-400 text-xs font-sf-semibold tracking-wider uppercase mb-2 border-y border-green-500/20 py-2">
                             AI Explanation
                        </h4>
                        <div className="bg-black/60 p-4 rounded-lg border border-green-500/10 text-neutral-300 text-sm leading-relaxed whitespace-pre-wrap mt-3">
                            {explanation}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );

    if (execution_id) {
        return <Link to={`/execution/${execution_id}`} className="block">{card}</Link>;
    }

    return card;
}
