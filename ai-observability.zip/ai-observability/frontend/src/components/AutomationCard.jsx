import { Link } from "react-router-dom";

export default function AutomationCard({ automation }) {
    const healthColor = {
        SUCCESS: "text-green-400 bg-green-500/10 border-green-500/20",
        FAILED: "text-red-400 bg-red-500/10 border-red-500/20",
        DELAYED: "text-yellow-400 bg-yellow-500/10 border-yellow-500/20",
    };

    const formatDate = (dateStr) => {
        if (!dateStr) return null;
        const d = new Date(dateStr);
        return d.toLocaleString('en-US', {
            month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    };

    return (
        <Link to={`/automation/${automation.id}`} className="block h-full cursor-pointer">
            <div className="h-full bg-white/5 backdrop-blur-md hover:bg-white/10 border border-white/10 rounded-xl p-6 transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-[1.02] flex flex-col justify-between group">
                <div>
                    <div className="flex items-center justify-between mb-3 shadow-sm pb-2 border-b border-white/5">
                        <h3 className="text-white text-lg font-nf-semibold font-sf-semibold truncate group-hover:text-green-300 transition-colors">
                            {automation.name}
                        </h3>
                        {automation.latest_health && (
                            <span className={`text-xs px-3 py-1 rounded-full font-sf-medium border ${healthColor[automation.latest_health] || "text-gray-400 bg-gray-500/10 border-gray-500/20"}`}>
                                {automation.latest_health}
                            </span>
                        )}
                    </div>
                    {automation.description && (
                        <p className="text-neutral-400 text-sm mb-4 line-clamp-2">
                            {automation.description}
                        </p>
                    )}
                </div>
                <div className="flex flex-col gap-2 text-xs text-neutral-500 mt-auto pt-4 border-t border-white/5 font-sf-medium">
                    <div className="flex justify-between items-center">
                        <span className="text-green-400 font-sf-regular tracking-widest uppercase">Executions</span>
                        <span className="text-white font-sf-semibold">{automation.execution_count || 0}</span>
                    </div>
                    {automation.last_run && (
                        <div className="flex justify-between items-center pt-1">
                            <span>Last Run</span>
                            <span>{formatDate(automation.last_run)}</span>
                        </div>
                    )}
                </div>
            </div>
        </Link>
    );
}
