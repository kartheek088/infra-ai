import { useState } from 'react';
import { getExecutionSummary } from '../services/api';
import LoadingSpinner from './LoadingSpinner';
import ExecutionCard from './ExecutionCard';

export default function ExecutionDashboard() {
    const [executionId, setExecutionId] = useState('');
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const [errorMsg, setErrorMsg] = useState('');

    const handleFetch = async (e) => {
        e.preventDefault();
        if (!executionId.trim()) return;

        setLoading(true);
        setErrorMsg('');
        setResult(null);

        try {
            const data = await getExecutionSummary(executionId);
            setResult(data);
        } catch (err) {
            setErrorMsg(err.message || 'Failed to fetch execution summary');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-8 max-w-5xl mx-auto font-sf-regular">
            {/* INPUT PANEL */}
            <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 shadow-2xl">
                <form onSubmit={handleFetch} className="flex flex-col sm:flex-row gap-4 items-center">
                    <input
                        type="text"
                        value={executionId}
                        onChange={(e) => setExecutionId(e.target.value)}
                        placeholder="Enter execution_id (e.g., exec_123)"
                        className="
              flex-1 bg-black/50 border border-white/20 text-white placeholder-white/40
              px-6 py-4 rounded-xl font-sf-medium tracking-wide text-lg w-full focus:outline-none focus:border-green-400 transition-colors shadow-inner
            "
                    />
                    <button
                        type="submit"
                        disabled={loading || !executionId.trim()}
                        className="
              px-10 py-4 leading-tight rounded-xl font-sf-bold text-lg tracking-wide
              bg-gradient-to-r from-green-400 to-emerald-500 text-black shadow-lg shadow-green-500/20 hover:shadow-green-500/40 hover:scale-[1.02] active:scale-95 disabled:opacity-50 disabled:pointer-events-none transition-all duration-200 whitespace-nowrap w-full sm:w-auto
            "
                    >
                        {loading ? 'Analyzing...' : 'Load Execution'}
                    </button>
                </form>

                {errorMsg && (
                    <div className="mt-6 bg-red-500/10 border border-red-500/20 rounded-lg p-4 text-red-400 text-sm tracking-wide font-sf-medium flex items-center gap-3">
                        <span className="text-lg">⚠</span> {errorMsg}
                    </div>
                )}
            </div>

            {loading && (
                <div className="flex justify-center py-16">
                    <LoadingSpinner />
                </div>
            )}

            {result && !loading && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <ExecutionCard data={result} />
                </div>
            )}

            {!loading && !result && !errorMsg && (
                <div className="bg-white/5 border border-white/10 rounded-2xl p-12 text-center text-neutral-500 font-sf-regular">
                    <div className="text-4xl mb-4">🔍</div>
                    <p className="text-lg text-neutral-400 font-sf-medium">Enter an Execution ID to begin analysis.</p>
                </div>
            )}
        </div>
    );
}
