from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.schemas import EventPayload, AutomationCreate
from app.services.ingestion import ingest_event
from app.services.automation_service import create_automation, get_automations
from app.models.db_models import Execution, Automation, Event

router = APIRouter()

@router.post("/ingest")
async def ingest(payload: dict, db: Session = Depends(get_db)):
    event = ingest_event(db, payload)
    return {"status": "ok", "execution_id": event.execution_id}

@router.post("/automation")
def save_automation(payload: AutomationCreate, db: Session = Depends(get_db)):
    auto = create_automation(db, payload)
    return auto

@router.get("/automation")
def list_automations(db: Session = Depends(get_db)):
    # Returns formatted dict from our service
    return get_automations(db)

@router.get("/automation/{automation_id}/executions")
def list_automation_executions(automation_id: int, db: Session = Depends(get_db)):
    execs = db.query(Execution).filter(Execution.automation_id == automation_id).order_by(Execution.created_at.desc()).all()
    return execs

@router.get("/executions/recent")
def list_recent_executions(db: Session = Depends(get_db)):
    execs = db.query(Execution).order_by(Execution.created_at.desc()).limit(10).all()
    results = []
    for ex in execs:
        auto_name = None
        if ex.automation_id:
            auto = db.query(Automation).filter(Automation.id == ex.automation_id).first()
            if auto:
                auto_name = auto.name
                
        results.append({
            "execution_id": ex.execution_id,
            "automation_name": auto_name,
            "health": ex.status,
            "total_tokens": ex.total_tokens,
            "total_cost": ex.total_cost,
            "timeline": ex.timeline_json,
            "anomalies": ex.anomalies_json,
            "explanation": ex.ai_analysis,
            "created_at": ex.created_at.isoformat() if ex.created_at else None
        })
    return results

@router.get("/execution/{execution_id}")
def get_execution_summary(execution_id: str, db: Session = Depends(get_db)):
    ex = db.query(Execution).filter(Execution.execution_id == execution_id).first()
    if not ex:
        raise HTTPException(status_code=404, detail="Execution not found")

    auto_name = None
    if ex.automation_id:
        auto = db.query(Automation).filter(Automation.id == ex.automation_id).first()
        if auto:
            auto_name = auto.name

    return {
        "execution_id": ex.execution_id,
        "automation_name": auto_name,
        "health": ex.status,
        "total_duration": ex.total_duration,
        "total_tokens": ex.total_tokens,
        "total_cost": ex.total_cost,
        "timeline": ex.timeline_json,
        "anomalies": ex.anomalies_json,
        "explanation": ex.ai_analysis,
        "created_at": ex.created_at.isoformat() if ex.created_at else None
    }

@router.get("/metrics")
def get_metrics(db: Session = Depends(get_db)):
    automations_count = db.query(Automation).count()
    executions_count = db.query(Execution).count()
    failures_count = db.query(Execution).filter(Execution.status == "FAILED").count()
    
    avg_latency = 0.0
    if executions_count > 0:
        execs = db.query(Execution).filter(Execution.total_duration != None).all()
        if execs:
            avg_latency = sum(ex.total_duration for ex in execs) / len(execs)
        
    return {
        "automations": automations_count,
        "executions": executions_count,
        "failures": failures_count,
        "avg_latency": round(avg_latency, 2)
    }
