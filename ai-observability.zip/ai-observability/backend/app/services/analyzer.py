from app.models.db_models import Event

def compute_execution_status(events):
    for e in events:
        if e.status == "FAILED":
            return "FAILED"
            
    for e in events:
        if e.duration and e.duration > 3:
            return "DELAYED"
            
    return "SUCCESS"

def detect_anomalies(events):
    anomalies = []
    
    for i, e in enumerate(events):
        if e.duration and e.duration > 3:
            anomalies.append(f"{e.step} latency spike")
            
        if e.tokens and e.tokens > 500:
            anomalies.append(f"{e.step} token spike")
            
        if e.status != "SUCCESS":
            anomalies.append(f"{e.step} failed")
            
        # Detect idle gaps (Timeline Gap Detection)
        if i > 0:
            prev_e = events[i - 1]
            # Assuming timestamps are sequential and ordered
            if e.timestamp and prev_e.timestamp:
                gap = (e.timestamp - prev_e.timestamp).total_seconds()
                if gap > 2:
                    anomalies.append(f"Idle gap detected before {e.step} ({gap:.1f}s)")

    return anomalies

def build_timeline_dict(events):
    steps = []
    for e in events:
        steps.append({
            "step": e.step,
            "status": e.status,
            "duration": e.duration,
            "tokens": e.tokens,
            "cost": e.cost,
            "timestamp": e.timestamp.isoformat() if e.timestamp else None
        })
    return {
        "execution_id": events[0].execution_id if events else None,
        "steps": steps
    }
