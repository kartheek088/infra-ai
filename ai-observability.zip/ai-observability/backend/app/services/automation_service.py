from sqlalchemy.orm import Session
from app.models.db_models import Automation, Execution
from app.models.schemas import AutomationCreate

def create_automation(db: Session, data: AutomationCreate):
    auto = Automation(
        name=data.name,
        description=data.description,
        source=data.source
    )
    db.add(auto)
    db.commit()
    db.refresh(auto)
    return auto

def get_automations(db: Session):
    # Using raw SQL or advanced SQLAlchemy to get count & last run
    # For MVP, simpler approach
    autos = db.query(Automation).order_by(Automation.created_at.desc()).all()
    results = []
    
    for auto in autos:
        execs = db.query(Execution).filter(Execution.automation_id == auto.id).order_by(Execution.created_at.desc()).all()
        # Fallback to general executions if automation_id isn't populated (e.g if we link them by name later)
        
        execution_count = len(execs)
        latest_health = execs[0].status if execs else None
        last_run = execs[0].created_at if execs else None
        
        results.append({
            "id": auto.id,
            "name": auto.name,
            "description": auto.description,
            "source": auto.source,
            "created_at": auto.created_at,
            "execution_count": execution_count,
            "latest_health": latest_health,
            "last_run": last_run
        })
        
    return results
