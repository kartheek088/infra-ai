import requests
from app.core.config import settings

def analyze_with_groq(timeline: dict, health: str, anomalies: list, total_tokens: int, total_cost: float):
    # Failsafe wrap
    if not settings.GROQ_API_KEY:
        return "Analysis unavailable. Failsafe triggered: Missing GROQ_API_KEY in backend config."
        
    try:
        headers = {
            "Authorization": f"Bearer {settings.GROQ_API_KEY}",
            "Content-Type": "application/json"
        }

        prompt = f"""
You are an AI governance analyst.

Execution Health: {health}
Detected Anomalies: {anomalies}
Total Tokens Used: {total_tokens}
Total Cost (USD): {total_cost}

Timeline:
{timeline}

Provide:
1. Analytical summary
2. Mention detected anomalies
3. Mention cost/token risks
4. Suggest improvements
Be concise but insightful.
"""

        payload = {
            "model": "llama-3.1-8b-instant",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.2
        }

        response = requests.post(settings.GROQ_URL, headers=headers, json=payload, timeout=10)
        response.raise_for_status()

        return response.json()["choices"][0]["message"]["content"]
    except Exception as e:
        print(f"[GROQ ERROR] {e}")
        return "Analysis unavailable. Failsafe triggered."
