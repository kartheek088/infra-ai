from sqlalchemy.orm import Session
from app.models.db_models import Event, Execution, Automation
from app.services.analyzer import compute_execution_status, detect_anomalies, build_timeline_dict
from app.services.groq_client import analyze_with_groq
import json

def normalize_event(payload: dict):
    return {
        "execution_id": payload.get("execution_id"),
        "workflow_id": payload.get("workflow_id"),
        "step": payload.get("step") or payload.get("node") or payload.get("tool"),
        "status": payload.get("status", "UNKNOWN"),
        "duration": payload.get("duration", 0.0),
        "tokens": payload.get("tokens", 0),
        "cost": payload.get("cost", 0.0),
        "source": payload.get("source", "unknown"),
        "tenant_id": payload.get("tenant_id", "default"),
        "raw_payload": payload
    }

def ingest_event(db: Session, payload: dict):
    norm = normalize_event(payload)
    execution_id = norm["execution_id"]
    
    print(f"[INGEST] {execution_id} - {norm['step']}")

    # Find automation if workflow_id provided
    automation_id = None
    if norm["workflow_id"]:
        # Try finding by exact integer ID first
        if str(norm["workflow_id"]).isdigit():
            auto = db.query(Automation).filter(Automation.id == int(norm["workflow_id"])).first()
            if auto:
                automation_id = auto.id
        
        # If not found by ID, try matching by string name
        if not automation_id:
            auto = db.query(Automation).filter(Automation.name == norm["workflow_id"]).first()
            if auto:
                automation_id = auto.id
    
    event = Event(
        execution_id=execution_id,
        workflow_id=norm["workflow_id"],
        automation_id=automation_id,
        tenant_id=norm["tenant_id"],
        source=norm["source"],
        step=norm["step"],
        status=norm["status"],
        duration=norm["duration"],
        tokens=norm["tokens"],
        cost=norm["cost"],
        raw_payload=norm["raw_payload"]
    )
    
    db.add(event)
    db.commit()
    db.refresh(event)

    update_execution(db, execution_id)
    return event

def update_execution(db: Session, execution_id: str):
    events = db.query(Event).filter(Event.execution_id == execution_id).order_by(Event.timestamp).all()
    if not events:
        return
        
    status = compute_execution_status(events)
    total_duration = sum(e.duration for e in events if e.duration)
    total_tokens = sum(e.tokens for e in events if e.tokens)
    total_cost = sum(e.cost for e in events if e.cost)
    
    anomalies = detect_anomalies(events)
    timeline = build_timeline_dict(events)
    
    # We only call Groq if we consider execution complete or just update it
    # We can always overwrite the ai_analysis
    ai_analysis = analyze_with_groq(timeline, status, anomalies, total_tokens, total_cost)
    
    # Check if execution already exists
    execution = db.query(Execution).filter(Execution.execution_id == execution_id).first()
    
    # Grab automation_id from first event if exists
    automation_id = events[0].automation_id
    
    if not execution:
        execution = Execution(
            execution_id=execution_id,
            automation_id=automation_id,
            status=status,
            total_duration=total_duration,
            total_tokens=total_tokens,
            total_cost=total_cost,
            timeline_json=timeline,
            anomalies_json=anomalies,
            ai_analysis=ai_analysis
        )
        db.add(execution)
    else:
        execution.status = status
        execution.total_duration = total_duration
        execution.total_tokens = total_tokens
        execution.total_cost = total_cost
        execution.timeline_json = timeline
        execution.anomalies_json = anomalies
        execution.ai_analysis = ai_analysis
        
    db.commit()
