from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from datetime import datetime

class AutomationCreate(BaseModel):
    name: str
    description: Optional[str] = None
    source: str

class AutomationResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    source: str
    created_at: datetime
    execution_count: Optional[int] = 0
    latest_health: Optional[str] = None
    last_run: Optional[datetime] = None

    class Config:
        from_attributes = True

class EventPayload(BaseModel):
    execution_id: str
    step: Optional[str] = None
    node: Optional[str] = None
    tool: Optional[str] = None
    workflow_id: Optional[str] = None
    status: str
    duration: Optional[float] = 0.0
    tokens: Optional[int] = 0
    cost: Optional[float] = 0.0
    source: Optional[str] = "unknown"
    tenant_id: Optional[str] = "default"
    metadata: Optional[Dict[str, Any]] = None

class ExecutionSummaryResponse(BaseModel):
    execution_id: str
    automation_name: Optional[str] = None
    health: str
    total_duration: float
    total_tokens: int
    total_cost: float
    timeline: Dict[str, Any]
    anomalies: List[str]
    explanation: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True
