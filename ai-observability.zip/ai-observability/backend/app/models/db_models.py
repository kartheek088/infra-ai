from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, JSON
from sqlalchemy.sql import func
from app.core.database import Base

class Automation(Base):
    __tablename__ = "automations"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    description = Column(String, nullable=True)
    source = Column(String, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Event(Base):
    __tablename__ = "execution_events"

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(String, index=True)
    workflow_id = Column(String, index=True, nullable=True)
    automation_id = Column(Integer, ForeignKey("automations.id"), nullable=True)
    tenant_id = Column(String, index=True, default="default")
    source = Column(String, index=True, default="unknown")
    step = Column(String)
    status = Column(String)
    duration = Column(Float, default=0.0)
    tokens = Column(Integer, default=0)
    cost = Column(Float, default=0.0)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    raw_payload = Column(JSON, nullable=True)

class Execution(Base):
    __tablename__ = "executions"

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(String, unique=True, index=True)
    automation_id = Column(Integer, ForeignKey("automations.id"), nullable=True)
    status = Column(String)
    total_duration = Column(Float, default=0.0)
    total_tokens = Column(Integer, default=0)
    total_cost = Column(Float, default=0.0)
    timeline_json = Column(JSON)
    anomalies_json = Column(JSON)
    ai_analysis = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
