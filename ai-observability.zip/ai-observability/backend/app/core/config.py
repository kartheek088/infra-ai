import os

class Config:
    GROQ_API_KEY = "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"
    GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"

settings = Config()
